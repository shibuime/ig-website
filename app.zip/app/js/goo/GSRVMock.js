window.gsrv = {
	track: function(){},
	exit: function(){}
};
