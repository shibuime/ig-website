import React from 'react'
import ReactDOM from 'react-dom'
import App from './app'
require('./css/style.scss');


ReactDOM.render(<App />, document.getElementById('App'))