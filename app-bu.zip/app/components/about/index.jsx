import React from 'react';

const About = () => <div>About</div>;

export default About;